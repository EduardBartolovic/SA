public class SimpleIfTest {
	public static void main(String[] args) {
		if(args.length > 0)
			System.out.println("It's greater than 0.");
		else
			System.out.println("It's less than 0.");
	}
}