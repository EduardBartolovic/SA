public abstract class ABCAbstractFake {
	public abstract int thisIsAbstract();
	abstract void thisIsAlsoAbstract(double k);
	public static void main(String[] args) {
		
	}

	public int thisIsNotabstractAbstract(int a){
		System.out.println(a);
		return 0;
	}

	void notAbstractabstract(){
		System.out.println("FAKE");
	}
}