public class MethodInString {
    void bar() {
        System.out.println("baaaar();");
    }
}
