public class FakeAnonymous {
	public static void main(String... args){
		fake$$1(5);
	}

	public static void fake$$1(int $$1a){
		System.out.println($$1a);
	}
}