public abstract class ABC {
    abstract void foo();
    
    void bar() {
        System.out.println(1);
    }
}
