public class PrivateFinal {
    private void f() {
        System.out.println(1);
    }
    
    final void g() {
        System.out.println(2);
    }
    
    static void h() {
        System.out.println(3);
    }
    
    public static void main(String... args) {
        
    }
}
