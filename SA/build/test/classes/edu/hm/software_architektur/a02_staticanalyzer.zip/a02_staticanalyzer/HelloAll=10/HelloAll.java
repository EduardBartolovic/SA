public class HelloAll {
    public static void main(String... args) {
        System.out.println("Hello");
    }
    public static void a(String... args) {
        System.out.println("Hello");
    }
    public static void b(String... args) {
        System.out.println("Hello");
    }
    public static void c(String... args) {
        System.out.println("Hello");
    }
    public static void d(String... args) {
        System.out.println("Hello");
    }
    public static void e(String... args) {
        System.out.println("Hello");
    }
    public static void f(String... args) {
        System.out.println("Hello");
    }
    public static void g(String... args) {
        System.out.println("Hello");
    }
    public static void h(String... args) {
        System.out.println("Hello");
    }
}
