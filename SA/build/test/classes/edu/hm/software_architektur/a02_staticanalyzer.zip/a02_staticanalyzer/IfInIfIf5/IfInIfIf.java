public class IfInIfIf {
    public static void main(String... args) {
        if(args.length > 0)
            if(args.length > 0)
                if(args.length > 0)
                    System.out.println("toComplicated :(");
    }
}
