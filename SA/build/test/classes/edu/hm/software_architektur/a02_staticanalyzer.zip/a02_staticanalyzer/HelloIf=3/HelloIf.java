public class HelloIf {
    public static void main(String... args) {
        if(args.length > 0)
            System.out.println("Hello");
    }
}
