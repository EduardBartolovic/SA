
public class ifeq {

    public void ifne(String ifne){

    }
}
