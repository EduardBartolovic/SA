public class While {
    public static void main(String... args) {
        int n = 10;
        while(n > 0) {
            System.out.println(n--);
        }
    }
}
