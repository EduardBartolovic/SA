public abstract class AbstractTest {
    static void foo() {
        System.out.println(1);
    }
    
    void bar() {
        System.out.println(2);
    }
}
