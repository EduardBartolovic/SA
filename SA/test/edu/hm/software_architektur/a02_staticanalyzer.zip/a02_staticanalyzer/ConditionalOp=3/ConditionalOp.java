public class ConditionalOp {
    public static void main(String... args) {
        System.out.println(args == null? 1: 2);
    }
}
